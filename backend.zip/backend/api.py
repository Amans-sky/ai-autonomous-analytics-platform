# backend/api.py

from fastapi import FastAPI, Query
from backend.agent_router import AgentRouter

app = FastAPI(
    title="AI Analytics Dashboard API",
    version="1.0.0"
)

router = AgentRouter()


@app.get("/")
def health():
    return {"status": "ok"}


@app.get("/analyze")
def analyze(query: str = Query(..., min_length=3)):
    # 🚫 No try/except for business logic
    # ✅ Router already handles guardrails safely
    return router.handle(query)

from fastapi import Body

@app.post("/analyze-view")
def analyze_view(payload: dict = Body(...)):
    """
    Phase 2: Sidebar-driven analytics
    """
    view = payload.get("view")
    base_query = payload.get("query", "revenue")

    view_to_prompt = {
        "kpi-overview": f"total {base_query} last month",
        "trend-analysis": f"trend of {base_query} over last 6 months",
        "breakdown": f"breakdown of {base_query} by region",
        "saved-insights": f"show saved insights",
    }

    final_query = view_to_prompt.get(view, base_query)

    return router.handle(final_query)

@app.exception_handler(Exception)
async def safe_exception_handler(request, exc):
    return {
        "status": "error",
        "message": str(exc)
    }
