import { useState } from "react";
import { DollarSign, ShoppingCart, Globe, Calendar } from "lucide-react";
import Navbar from "./Navbar";
import QueryInput from "./QueryInput";
import KpiCard from "./KpiCard";
import ChartPanel from "./ChartPanel";
import InsightPanel from "./InsightPanel";

// Mock chart data - structured for easy backend integration
const mockChartData = [
  { name: "Jan", value: 4200 },
  { name: "Feb", value: 4800 },
  { name: "Mar", value: 3100 },
  { name: "Apr", value: 4500 },
  { name: "May", value: 5200 },
  { name: "Jun", value: 5800 },
];

// Mock KPI data - structured for easy backend integration
const mockKpis = [
  {
    title: "Total Revenue",
    value: "$27.6K",
    subtitle: "Last 6 months",
    icon: DollarSign,
    trend: { value: "+12.5%", isPositive: true },
  },
  {
    title: "Total Orders",
    value: "1,284",
    subtitle: "Last 6 months",
    icon: ShoppingCart,
    trend: { value: "+8.2%", isPositive: true },
  },
  {
    title: "Regions Analyzed",
    value: "4",
    subtitle: "North, South, East, West",
    icon: Globe,
  },
  {
    title: "Time Range",
    value: "6 Months",
    subtitle: "Jan 2024 - Jun 2024",
    icon: Calendar,
  },
];

const Dashboard = () => {
  const [insight, setInsight] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [chartData, setChartData] = useState(mockChartData);

  /**
   * Handles query submission and calls the backend API
   * API endpoint: GET /analyze?query=<natural_language_question>
   */
  const handleQuerySubmit = async (query: string) => {
    setIsLoading(true);
    setError(null);
    setInsight(null);

    try {
      // Backend API integration point
      const response = await fetch(
        `/analyze?query=${encodeURIComponent(query)}`
      );

      if (!response.ok) {
        throw new Error(
          `Analysis failed: ${response.status} ${response.statusText}`
        );
      }

      const data = await response.json();

      // Set the AI insight from the response
      setInsight(
        data.insight ||
          data.response ||
          data.message ||
          JSON.stringify(data, null, 2)
      );

      // Update chart data if provided by backend
      if (data.chartData && Array.isArray(data.chartData)) {
        setChartData(data.chartData);
      }
    } catch (err) {
      // For demo purposes, show a mock response if the backend is unavailable
      if (err instanceof TypeError && err.message.includes("fetch")) {
        setInsight(
          `Analysis for: "${query}"\n\nThe revenue decline in March in the West region can be attributed to several factors:\n\n1. Seasonal patterns show historically lower Q1 performance in western markets\n2. Two key enterprise accounts delayed renewals pending budget approvals\n3. A competitor launched a promotional campaign that temporarily affected market share\n\nRecommendation: Focus on enterprise account retention and consider targeted promotions in the West region for Q1 periods.`
        );
      } else {
        setError(
          err instanceof Error ? err.message : "An unexpected error occurred"
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        {/* Query Input Section */}
        <section className="mb-8">
          <QueryInput onSubmit={handleQuerySubmit} isLoading={isLoading} />
        </section>

        {/* KPI Summary Section */}
        <section className="mb-8">
          <h2 className="mb-4 text-sm font-medium uppercase tracking-wide text-muted-foreground">
            Key Metrics
          </h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {mockKpis.map((kpi, index) => (
              <KpiCard
                key={index}
                title={kpi.title}
                value={kpi.value}
                subtitle={kpi.subtitle}
                icon={kpi.icon}
                trend={kpi.trend}
              />
            ))}
          </div>
        </section>

        {/* Chart and Insight Section */}
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <ChartPanel
            title="Metric Trend Analysis"
            data={chartData}
            chartType="line"
            xAxisLabel="Time"
            yAxisLabel="Revenue ($)"
          />
          <InsightPanel
            insight={insight}
            isLoading={isLoading}
            error={error}
          />
        </section>
      </main>
    </div>
  );
};

export default Dashboard;
