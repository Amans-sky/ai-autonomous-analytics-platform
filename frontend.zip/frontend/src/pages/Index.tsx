import Dashboard from "@/components/dashboard/Dashboard";

const Index = () => {
  return <Dashboard />;
};

export default Index;
